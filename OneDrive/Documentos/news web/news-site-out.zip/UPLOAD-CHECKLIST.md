# Upload Instructions Checklist

Follow these steps to upload your website to your web hosting:

## Pre-Upload Check

- [x] All HTML files are included (index.html, about.html, contact.html)
- [x] All CSS files are in the css/ folder
- [x] All JavaScript files are in the js/ folder
- [x] All images are in the images/ folder
- [x] articles-data.js has been updated with real article data
- [x] The Popular Categories section has been removed
- [x] Image placeholders are working

## Upload Steps

1. Open FileZilla and connect to your hosting:
   - Host: ftp.trendingnews.org.za (or your FTP server)
   - Username: [Your FTP username]
   - Password: [Your FTP password]
   - Port: 21

2. On the remote site (right panel), navigate to your web root (usually public_html)

3. Select all files and folders from the READY-TO-UPLOAD folder on your local machine

4. Upload them to your web root directory on the remote server

5. Ensure that all directories and files have the correct permissions:
   - HTML/CSS/JS files: 644
   - Folders: 755

## Post-Upload Verification

1. Visit your website URL (e.g., https://trendingnews.org.za)

2. Check that:
   - The homepage loads with all styling and images
   - Real articles are displayed
   - The search function works
   - All links function properly

3. Test on both desktop and mobile devices to ensure responsive design works

## Troubleshooting

If your site doesn't appear correctly:
- Check if all files were uploaded
- Verify file paths in the HTML are correct
- Make sure JavaScript is enabled in your browser
- Clear your browser cache and reload

## Support

If you encounter any issues, please contact:
- Email: support@trendingnews.org.za
- Phone: +27 12 345 6789