/**
 * Trending News Site JavaScript
 * This file contains all the interactive functionality for the news site.
 */

/**
 * Function to load the articles data dynamically
 */
function loadArticlesData() {
    return new Promise((resolve, reject) => {
        // If we already have the data, resolve immediately
        if (window.articleData) {
            resolve(window.articleData);
            return;
        }

        // Create a script element to load the articles-data.js file
        const scriptEl = document.createElement('script');
        scriptEl.src = 'articles-data.js';
        scriptEl.onload = function() {
            console.log("Loaded articles-data.js dynamically");
            if (window.articleData) {
                resolve(window.articleData);
            } else {
                reject(new Error("Failed to get article data after loading script"));
            }
        };
        scriptEl.onerror = function() {
            reject(new Error("Failed to load articles-data.js"));
        };
        document.head.appendChild(scriptEl);
    });
}

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the site
    initializeSite();
});

/**
 * Initialize all site functionality
 */
function initializeSite() {
    console.log("Initializing site...");
    
    // Load the articles data
    loadArticlesData()
        .then(data => {
            console.log("Successfully loaded article data with " + data.length + " articles");
            loadRealArticles(); // Load real articles from the static data
            loadFeaturedArticles(); // Load featured articles
        })
        .catch(error => {
            console.error("Failed to load article data:", error);
            // Try using any available static data
            if (window.articleData) {
                loadRealArticles(); 
                loadFeaturedArticles();
            } else {
                // Show error message in the articles container
                const articlesContainer = document.querySelector('.news-grid');
                if (articlesContainer) {
                    articlesContainer.innerHTML = `
                        <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                            <h3>Unable to load articles</h3>
                            <p>Please try refreshing the page or check your connection.</p>
                        </div>
                    `;
                }
            }
        });
        
    // Setup other site functionality regardless of article loading
    setupSearchFunctionality();
    setupPaginationControls();
    setupSubscribeForm();
    setupContactForm();
    highlightActiveNavLink();
    setupSearchFunctionality();
    setupPaginationControls();
    setupSubscribeForm();
    setupContactForm();
    highlightActiveNavLink();
}

/**
 * Load real articles from the static data
 */
function loadRealArticles() {
    const articlesContainer = document.querySelector('.news-grid');
    if (!articlesContainer) {
        console.error('Articles container not found');
        return;
    }
    
    // Clear the container
    articlesContainer.innerHTML = '';
    
    // Check if we have article data available and output debug info
    console.log('Article data available:', window.articleData ? 'Yes' : 'No');
    if (window.articleData) {
        console.log('Number of articles:', window.articleData.length);
        console.log('Sample first article:', window.articleData[0]);
    }
    
    // Check if we have article data available
    if (window.articleData && window.articleData.length > 0) {
        try {
            // Loop through the articles and create cards
            window.articleData.forEach(article => {
                if (!article || !article.title) {
                    console.warn('Invalid article found:', article);
                    return;
                }
                const articleCard = createArticleCard(article);
                articlesContainer.appendChild(articleCard);
            });
        } catch (error) {
            console.error('Error rendering articles:', error);
            articlesContainer.innerHTML = `
                <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                    <h3>Error displaying articles</h3>
                    <p>Technical details: ${error.message}</p>
                </div>
            `;
        }
    } else {
        // Show no results message if no articles are available
        articlesContainer.innerHTML = generateNoResultsHTML();
    }
}

/**
 * Create an article card DOM element
 */
function createArticleCard(article) {
    const card = document.createElement('div');
    card.className = 'article-card';
    
    // Format the date
    const publishDate = new Date(article.publishedAt);
    const formattedDate = publishDate.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    // Create card content
    card.innerHTML = `
        <div class="article-image">
            <img src="${article.image}" alt="${article.title}" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg width=\'400\' height=\'250\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23e0e0e0\'/%3E%3C/svg%3E'; this.classList.add('placeholder-img');" crossorigin="anonymous">
            <span class="article-category">${article.category}</span>
        </div>
        <div class="article-content">
            <h3 class="article-title">${article.title}</h3>
            <p class="article-excerpt">${article.originalDescription}</p>
            <div class="article-meta">
                <span>${article.country}</span>
                <span>${formattedDate}</span>
                <span>${article.readingTime}</span>
            </div>
        </div>
    `;
    
    // Add click event to the card
    card.addEventListener('click', function() {
        window.open(article.originalUrl, '_blank');
    });
    
    return card;
}

/**
 * Set up the search functionality
 */
function setupSearchFunctionality() {
    const searchForm = document.querySelector('.search-controls');
    const searchInput = document.querySelector('.search-controls input');
    const countrySelect = document.querySelector('.search-controls select:first-of-type');
    const categorySelect = document.querySelector('.search-controls select:last-of-type');
    const searchButton = document.querySelector('.search-controls button');
    
    if (!searchButton) return;
    
    searchButton.addEventListener('click', function(e) {
        e.preventDefault();
        performSearch();
    });
    
    // Add enter key support for search input
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch();
            }
        });
    }
    
    // Show all stories button functionality
    const showAllButton = document.querySelector('.no-results button');
    if (showAllButton) {
        showAllButton.addEventListener('click', function() {
            if (searchInput) searchInput.value = '';
            if (countrySelect) countrySelect.value = '';
            if (categorySelect) categorySelect.value = '';
            performSearch();
        });
    }
    
    // Perform the search based on input values
    function performSearch() {
        const searchValue = searchInput ? searchInput.value.toLowerCase().trim() : '';
        const countryValue = countrySelect ? countrySelect.value : '';
        const categoryValue = categorySelect ? categorySelect.value : '';
        
        console.log('Searching for:', {
            query: searchValue,
            country: countryValue,
            category: categoryValue
        });
        
        const resultsContainer = document.querySelector('.news-grid');
        if (!resultsContainer) return;
        
        // Clear the container
        resultsContainer.innerHTML = '';
        
        // Filter the articles
        let filteredArticles = window.articleData || [];
        
        if (searchValue) {
            filteredArticles = filteredArticles.filter(article => 
                article.title.toLowerCase().includes(searchValue) || 
                article.originalDescription.toLowerCase().includes(searchValue) ||
                (article.tags && article.tags.some(tag => tag.toLowerCase().includes(searchValue)))
            );
        }
        
        if (countryValue && countryValue !== '') {
            filteredArticles = filteredArticles.filter(article => 
                article.country === countryValue
            );
        }
        
        if (categoryValue && categoryValue !== '') {
            filteredArticles = filteredArticles.filter(article => 
                article.category === categoryValue
            );
        }
        
        // Display filtered results or no results message
        if (filteredArticles.length > 0) {
            filteredArticles.forEach(article => {
                const articleCard = createArticleCard(article);
                resultsContainer.appendChild(articleCard);
            });
        } else {
            resultsContainer.innerHTML = generateNoResultsHTML();
            
            // Re-attach event listener to the show all button
            const showAllButton = document.querySelector('.no-results button');
            if (showAllButton) {
                showAllButton.addEventListener('click', function() {
                    if (searchInput) searchInput.value = '';
                    if (countrySelect) countrySelect.value = '';
                    if (categorySelect) categorySelect.value = '';
                    loadRealArticles();
                });
            }
        }
    }
}

/**
 * Set up pagination controls
 */
function setupPaginationControls() {
    const prevButton = document.querySelector('.pagination-inner button:first-child');
    const nextButton = document.querySelector('.pagination-inner button:last-child');
    
    if (prevButton) {
        prevButton.addEventListener('click', function() {
            if (!this.disabled) {
                console.log('Navigate to previous page');
                // In a real implementation, this would load the previous page
            }
        });
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', function() {
            if (!this.disabled) {
                console.log('Navigate to next page');
                // In a real implementation, this would load the next page
            }
        });
    }
}

/**
 * Set up the subscription form
 */
function setupSubscribeForm() {
    const subscribeForm = document.querySelector('.subscribe-form');
    const emailInput = document.querySelector('.subscribe-form input');
    const subscribeButton = document.querySelector('.subscribe-form button');
    
    if (!subscribeForm || !subscribeButton) return;
    
    subscribeButton.addEventListener('click', function(e) {
        e.preventDefault();
        
        const email = emailInput ? emailInput.value.trim() : '';
        if (!email || !isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // In a real implementation, this would make an API request to save the email
        console.log('Subscribing email:', email);
        
        // Show success message
        if (emailInput) emailInput.value = '';
        alert('Thank you for subscribing to our newsletter!');
    });
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

/**
 * Set up the contact form
 */
function setupContactForm() {
    const contactForm = document.querySelector('.contact-form');
    
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = contactForm.querySelector('#name').value.trim();
        const email = contactForm.querySelector('#email').value.trim();
        const subject = contactForm.querySelector('#subject').value.trim();
        const message = contactForm.querySelector('#message').value.trim();
        
        // Validate form
        if (!name || !email || !subject || !message) {
            alert('Please fill in all fields');
            return;
        }
        
        if (!isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // In a real implementation, this would make an API request to send the message
        console.log('Contact form submission:', { name, email, subject, message });
        
        // Show success message and reset form
        alert('Your message has been sent. We will get back to you soon!');
        contactForm.reset();
    });
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

/**
 * Highlight the active navigation link based on the current page
 */
function highlightActiveNavLink() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        // Remove any existing active class
        link.classList.remove('active');
        
        // Get the href attribute and normalize it
        const href = link.getAttribute('href');
        if (!href) return;
        
        // Determine if this link is for the current page
        if (currentPath === '/' && href === 'index.html') {
            link.classList.add('active');
        } else if (currentPath.includes(href) && href !== 'index.html') {
            link.classList.add('active');
        }
    });
}

/**
 * Load featured articles for the featured section
 */
function loadFeaturedArticles() {
    const featuredContainer = document.querySelector('.featured-grid');
    if (!featuredContainer) {
        console.error('Featured container not found');
        return;
    }
    
    if (!window.articleData || !window.articleData.length) {
        console.error('No article data available for featured articles');
        featuredContainer.innerHTML = '<div class="featured-placeholder">Featured articles will appear here</div>';
        return;
    }
    
    try {
        // Take the first 3 articles for featured display
        const featuredArticles = window.articleData.slice(0, 3);
        
        featuredContainer.innerHTML = '';
        
        featuredArticles.forEach(article => {
            if (!article || !article.title) {
                console.warn('Invalid article found for featured section:', article);
                return;
            }
            
            const featuredCard = document.createElement('div');
            featuredCard.className = 'featured-card';
            
            // Format the date
            const publishDate = new Date(article.publishedAt);
            const formattedDate = publishDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            featuredCard.innerHTML = `
                <div class="featured-image">
                    <img src="${article.image}" alt="${article.title}" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg width=\'400\' height=\'250\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23e0e0e0\'/%3E%3C/svg%3E'; this.classList.add('placeholder-img');" crossorigin="anonymous">
                    <span class="featured-category">${article.category}</span>
                </div>
                <div class="featured-content">
                    <h3 class="featured-title">${article.title}</h3>
                    <p class="featured-excerpt">${article.originalDescription}</p>
                    <div class="featured-meta">
                        <span>${article.country}</span>
                        <span>${formattedDate}</span>
                    </div>
                </div>
            `;
            
            // Add click event to the card
            featuredCard.addEventListener('click', function() {
                window.open(article.originalUrl, '_blank');
            });
            
            featuredContainer.appendChild(featuredCard);
        });
    } catch (error) {
        console.error('Error rendering featured articles:', error);
        featuredContainer.innerHTML = `
            <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                <h3>Error displaying featured articles</h3>
                <p>Please try refreshing the page.</p>
            </div>
        `;
    }
}

/**
 * Set up category filter buttons
 */
function setupCategoryFilters() {
    const categoryCards = document.querySelectorAll('.category-card');
    
    categoryCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            const category = this.getAttribute('data-category');
            
            // Set the category filter in the search section
            const categorySelect = document.querySelector('.search-controls select:last-of-type');
            if (categorySelect) {
                categorySelect.value = category;
            }
            
            // Trigger the search
            const searchButton = document.querySelector('.search-controls button');
            if (searchButton) {
                searchButton.click();
            }
            
            // Scroll to results
            const contentSection = document.querySelector('.content-section');
            if (contentSection) {
                contentSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

/**
 * Generate HTML for no results message
 */
function generateNoResultsHTML() {
    return `
        <div class="no-results">
            <div class="no-results-icon"></div>
            <h3>No articles found</h3>
            <p>Try adjusting your search terms or filters to find more stories.</p>
            <button>Show All Stories</button>
        </div>
    `;
}