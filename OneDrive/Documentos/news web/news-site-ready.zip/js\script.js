/**
 * Trending News Site JavaScript
 * This file contains all the interactive functionality for the news site.
 */

// Ensure articleData is available
let articleData;

// Log at the start of the script
console.log('Script.js starting, checking global articleData:', window.articleData ? 'exists with ' + window.articleData.length + ' articles' : 'missing');

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, checking articleData again:', window.articleData ? 'exists with ' + window.articleData.length + ' articles' : 'missing');
    
    // Initialize the site immediately using embedded data
    initializeSite();
});

/**
 * Initialize all site functionality
 */
function initializeSite() {
    console.log("Initializing site...");
    
    // Try to display articles with whatever data we have
    if (window.articleData && window.articleData.length > 0) {
        console.log("Found article data in window object:", window.articleData.length, "articles");
        articleData = window.articleData;
        loadRealArticles();
        loadFeaturedArticles();
    } else if (articleData && articleData.length > 0) {
        console.log("Using locally loaded article data:", articleData.length, "articles");
        loadRealArticles();
        loadFeaturedArticles();
    } else {
        console.error("No article data available");
        // Fall back to hardcoded articles
        console.log("Using fallback hardcoded articles");
        window.articleData = getHardcodedArticles();
        articleData = window.articleData;
        loadRealArticles();
        loadFeaturedArticles();
    }
        
    // Setup other site functionality regardless of article loading
    setupSearchFunctionality();
    setupPaginationControls();
    setupSubscribeForm();
    setupContactForm();
    highlightActiveNavLink();
}

/**
 * Provides fallback articles if no data is available
 */
function getHardcodedArticles() {
    return [
        {
            id: "fallback1",
            title: "African Union Announces New Climate Initiative",
            originalDescription: "The African Union has launched a continent-wide initiative to combat climate change effects in vulnerable regions.",
            image: "https://www.un.org/africarenewal/sites/www.un.org.africarenewal/files/styles/homepage_top_image_1140x300/public/2023-05/african%20union%20summit%20sanusi.jpeg",
            category: "Environment",
            country: "Ethiopia",
            publishedAt: "2025-10-15T12:30:00Z",
            readingTime: "3 min read",
            originalUrl: "#"
        },
        {
            id: "fallback2",
            title: "New Tech Hub Opens in Nairobi",
            originalDescription: "Kenya's capital sees the opening of a major technology innovation center expected to create thousands of jobs.",
            image: "https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/0b19/live/bbbfdc20-ac11-11f0-ba75-093eca1ac29b.jpg",
            category: "Technology",
            country: "Kenya",
            publishedAt: "2025-10-16T09:15:00Z",
            readingTime: "4 min read",
            originalUrl: "#"
        },
        {
            id: "fallback3",
            title: "South African Renewable Energy Project Sets New Record",
            originalDescription: "A solar farm in Northern Cape becomes the continent's largest renewable energy installation.",
            image: "https://ichef.bbci.co.uk/ace/standard/976/cpsprodpb/9da3/live/f935ad20-ab60-11f0-aa13-0b0479f6f42a.jpg",
            category: "Energy",
            country: "South Africa",
            publishedAt: "2025-10-14T14:45:00Z",
            readingTime: "2 min read",
            originalUrl: "#"
        }
    ];
}

/**
 * Load real articles from the static data
 */
function loadRealArticles() {
    const articlesContainer = document.querySelector('.news-grid');
    if (!articlesContainer) {
        console.error('Articles container not found');
        return;
    }
    
    // Clear the container
    articlesContainer.innerHTML = '';
    
    // Use either the global or local article data
    const articles = articleData || window.articleData || [];
    
    console.log('Loading articles:', articles.length);
    
    // Check if we have any articles to display
    if (articles && articles.length > 0) {
        try {
            // Loop through the articles and create cards
            articles.forEach(article => {
                if (!article || !article.title) {
                    console.warn('Invalid article found:', article);
                    return;
                }
                const articleCard = createArticleCard(article);
                articlesContainer.appendChild(articleCard);
            });
        } catch (error) {
            console.error('Error rendering articles:', error);
            articlesContainer.innerHTML = `
                <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                    <h3>Error displaying articles</h3>
                    <p>Technical details: ${error.message}</p>
                </div>
            `;
        }
    } else {
        // Show no results message if no articles are available
        articlesContainer.innerHTML = `
            <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                <h3>No articles found</h3>
                <p>There was a problem loading the articles. Please try refreshing the page.</p>
                <button onclick="location.reload()">Reload Page</button>
            </div>
        `;
    }
}

/**
 * Create an article card DOM element
 */
function createArticleCard(article) {
    const card = document.createElement('div');
    card.className = 'article-card';
    
    // Format the date
    const publishDate = new Date(article.publishedAt);
    const formattedDate = publishDate.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    // Create card content
    card.innerHTML = `
        <div class="article-image">
            <img src="${article.image}" alt="${article.title}" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg width=\'400\' height=\'250\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23e0e0e0\'/%3E%3C/svg%3E'; this.classList.add('placeholder-img');" crossorigin="anonymous">
            <span class="article-category">${article.category}</span>
        </div>
        <div class="article-content">
            <h3 class="article-title">${article.title}</h3>
            <p class="article-excerpt">${article.originalDescription}</p>
            <div class="article-meta">
                <span>${article.country}</span>
                <span>${formattedDate}</span>
                <span>${article.readingTime}</span>
            </div>
        </div>
    `;
    
    // Add click event to the card
    card.addEventListener('click', function() {
        window.open(article.originalUrl, '_blank');
    });
    
    return card;
}

/**
 * Set up the search functionality
 */
function setupSearchFunctionality() {
    const searchForm = document.querySelector('.search-controls');
    const searchInput = document.querySelector('.search-controls input');
    const countrySelect = document.querySelector('.search-controls select:first-of-type');
    const categorySelect = document.querySelector('.search-controls select:last-of-type');
    const searchButton = document.querySelector('.search-controls button');
    
    if (!searchButton) return;
    
    searchButton.addEventListener('click', function(e) {
        e.preventDefault();
        performSearch();
    });
    
    // Add enter key support for search input
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch();
            }
        });
    }
    
    // Show all stories button functionality
    const showAllButton = document.querySelector('.no-results button');
    if (showAllButton) {
        showAllButton.addEventListener('click', function() {
            if (searchInput) searchInput.value = '';
            if (countrySelect) countrySelect.value = '';
            if (categorySelect) categorySelect.value = '';
            performSearch();
        });
    }
    
    // Perform the search based on input values
    function performSearch() {
        const searchValue = searchInput ? searchInput.value.toLowerCase().trim() : '';
        const countryValue = countrySelect ? countrySelect.value : '';
        const categoryValue = categorySelect ? categorySelect.value : '';
        
        console.log('Searching for:', {
            query: searchValue,
            country: countryValue,
            category: categoryValue
        });
        
        const resultsContainer = document.querySelector('.news-grid');
        if (!resultsContainer) return;
        
        // Clear the container
        resultsContainer.innerHTML = '';
        
        // Filter the articles
        let filteredArticles = window.articleData || [];
        
        if (searchValue) {
            filteredArticles = filteredArticles.filter(article => 
                article.title.toLowerCase().includes(searchValue) || 
                article.originalDescription.toLowerCase().includes(searchValue) ||
                (article.tags && article.tags.some(tag => tag.toLowerCase().includes(searchValue)))
            );
        }
        
        if (countryValue && countryValue !== '') {
            filteredArticles = filteredArticles.filter(article => 
                article.country === countryValue
            );
        }
        
        if (categoryValue && categoryValue !== '') {
            filteredArticles = filteredArticles.filter(article => 
                article.category === categoryValue
            );
        }
        
        // Display filtered results or no results message
        if (filteredArticles.length > 0) {
            filteredArticles.forEach(article => {
                const articleCard = createArticleCard(article);
                resultsContainer.appendChild(articleCard);
            });
        } else {
            resultsContainer.innerHTML = generateNoResultsHTML();
            
            // Re-attach event listener to the show all button
            const showAllButton = document.querySelector('.no-results button');
            if (showAllButton) {
                showAllButton.addEventListener('click', function() {
                    if (searchInput) searchInput.value = '';
                    if (countrySelect) countrySelect.value = '';
                    if (categorySelect) categorySelect.value = '';
                    loadRealArticles();
                });
            }
        }
    }
}

/**
 * Set up pagination controls
 */
function setupPaginationControls() {
    const prevButton = document.querySelector('.pagination-inner button:first-child');
    const nextButton = document.querySelector('.pagination-inner button:last-child');
    
    if (prevButton) {
        prevButton.addEventListener('click', function() {
            if (!this.disabled) {
                console.log('Navigate to previous page');
                // In a real implementation, this would load the previous page
            }
        });
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', function() {
            if (!this.disabled) {
                console.log('Navigate to next page');
                // In a real implementation, this would load the next page
            }
        });
    }
}

/**
 * Set up the subscription form
 */
function setupSubscribeForm() {
    const subscribeForm = document.querySelector('.subscribe-form');
    const emailInput = document.querySelector('.subscribe-form input');
    const subscribeButton = document.querySelector('.subscribe-form button');
    
    if (!subscribeForm || !subscribeButton) return;
    
    subscribeButton.addEventListener('click', function(e) {
        e.preventDefault();
        
        const email = emailInput ? emailInput.value.trim() : '';
        if (!email || !isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // In a real implementation, this would make an API request to save the email
        console.log('Subscribing email:', email);
        
        // Show success message
        if (emailInput) emailInput.value = '';
        alert('Thank you for subscribing to our newsletter!');
    });
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

/**
 * Set up the contact form
 */
function setupContactForm() {
    const contactForm = document.querySelector('.contact-form');
    
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = contactForm.querySelector('#name').value.trim();
        const email = contactForm.querySelector('#email').value.trim();
        const subject = contactForm.querySelector('#subject').value.trim();
        const message = contactForm.querySelector('#message').value.trim();
        
        // Validate form
        if (!name || !email || !subject || !message) {
            alert('Please fill in all fields');
            return;
        }
        
        if (!isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // In a real implementation, this would make an API request to send the message
        console.log('Contact form submission:', { name, email, subject, message });
        
        // Show success message and reset form
        alert('Your message has been sent. We will get back to you soon!');
        contactForm.reset();
    });
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

/**
 * Highlight the active navigation link based on the current page
 */
function highlightActiveNavLink() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        // Remove any existing active class
        link.classList.remove('active');
        
        // Get the href attribute and normalize it
        const href = link.getAttribute('href');
        if (!href) return;
        
        // Determine if this link is for the current page
        if (currentPath === '/' && href === 'index.html') {
            link.classList.add('active');
        } else if (currentPath.includes(href) && href !== 'index.html') {
            link.classList.add('active');
        }
    });
}

/**
 * Load featured articles for the featured section
 */
function loadFeaturedArticles() {
    const featuredContainer = document.querySelector('.featured-grid');
    if (!featuredContainer) {
        console.error('Featured container not found');
        return;
    }
    
    // Use either the global or local article data
    const articles = articleData || window.articleData || [];
    
    if (!articles || articles.length === 0) {
        console.error('No article data available for featured articles');
        featuredContainer.innerHTML = '<div class="featured-placeholder">Featured articles will appear here</div>';
        return;
    }
    
    try {
        // Take the first 3 articles for featured display
        const featuredArticles = articles.slice(0, 3);
        
        featuredContainer.innerHTML = '';
        
        featuredArticles.forEach(article => {
            if (!article || !article.title) {
                console.warn('Invalid article found for featured section:', article);
                return;
            }
            
            const featuredCard = document.createElement('div');
            featuredCard.className = 'featured-card';
            
            // Format the date
            const publishDate = new Date(article.publishedAt);
            const formattedDate = publishDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            
            featuredCard.innerHTML = `
                <div class="featured-image">
                    <img src="${article.image}" alt="${article.title}" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg width=\'400\' height=\'250\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'400\' height=\'250\' fill=\'%23e0e0e0\'/%3E%3C/svg%3E'; this.classList.add('placeholder-img');" crossorigin="anonymous">
                    <span class="featured-category">${article.category}</span>
                </div>
                <div class="featured-content">
                    <h3 class="featured-title">${article.title}</h3>
                    <p class="featured-excerpt">${article.originalDescription}</p>
                    <div class="featured-meta">
                        <span>${article.country}</span>
                        <span>${formattedDate}</span>
                    </div>
                </div>
            `;
            
            // Add click event to the card
            featuredCard.addEventListener('click', function() {
                window.open(article.originalUrl, '_blank');
            });
            
            featuredContainer.appendChild(featuredCard);
        });
    } catch (error) {
        console.error('Error rendering featured articles:', error);
        featuredContainer.innerHTML = `
            <div class="error-message" style="grid-column: span 3; text-align: center; padding: 2rem;">
                <h3>Error displaying featured articles</h3>
                <p>Please try refreshing the page.</p>
            </div>
        `;
    }
}

/**
 * Set up category filter buttons
 */
function setupCategoryFilters() {
    const categoryCards = document.querySelectorAll('.category-card');
    
    categoryCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            const category = this.getAttribute('data-category');
            
            // Set the category filter in the search section
            const categorySelect = document.querySelector('.search-controls select:last-of-type');
            if (categorySelect) {
                categorySelect.value = category;
            }
            
            // Trigger the search
            const searchButton = document.querySelector('.search-controls button');
            if (searchButton) {
                searchButton.click();
            }
            
            // Scroll to results
            const contentSection = document.querySelector('.content-section');
            if (contentSection) {
                contentSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

/**
 * Generate HTML for no results message
 */
function generateNoResultsHTML() {
    return `
        <div class="no-results">
            <div class="no-results-icon"></div>
            <h3>No articles found</h3>
            <p>Try adjusting your search terms or filters to find more stories.</p>
            <button>Show All Stories</button>
        </div>
    `;
}